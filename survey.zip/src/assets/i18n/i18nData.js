export default {
    en: {
        Lang: 'Language'
    },
    fr: {
        Lang: 'Langue'
    },
    it: {
        Lang: 'Linguaggio'
    }
}