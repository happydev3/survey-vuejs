<template>
     <footer class="it-footer">
      <div class="it-footer-main">
        <div class="container">
          <section>
            <div class="row clearfix">
              <div class="col-sm-12">
                <div class="it-brand-wrapper">
                  <a href="/">
                    <img src="@/assets/images/logo arpa colori.svg" class="icon">
                    <div class="it-brand-text">
                      <h2 class="no_toc">CO2 footprint calculator</h2>
                      <h3 class="no_toc d-none d-md-block">Calcola l'impronta carbonica della tua famiglia</h3>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </section>
          <section class="py-4 border-white border-top">
            <div class="row">
              <div class="col-lg-4 col-md-4 pb-2">
                <h4><a href="https://www.arpa.piemonte.it/contatti" target="_blank" title="Vai alla pagina: Contatti">Contatti</a></h4>
                <p>
                  <strong>ARPA Piemonte </strong><br> via Pio VII, 9 - 10135 Torino - tel. 011 1968 0111 fax 011 1968 1471 - Partita IVA 07176380017
                </p>
                <div class="link-list-wrapper">
                  <ul class="footer-list link-list clearfix">
                    <li><a class="list-item" href="mailto:protocollo@pec.arpa.piemonte.it" title="Posta Elettronica Certificata">PEC</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 pb-2">
                <a href="http://www.cclimatt.eu" target="_blank"><img class="img-fluid" alt="CClimaTT logo" src="@/assets/images/footer.png"></a>
              </div>
              <div class="col-lg-4 col-md-4 pb-2">
                <a href="http://www.interreg-alcotra.eu" target="_blank"><img class="img-fluid" alt="interreg ALCOTRA logo" src="@/assets/images/logo.png"></a>
              </div>
            </div>
          </section>
        </div>
      </div>
      <div class="it-footer-small-prints clearfix">
        <div class="container">
          <h3 class="sr-only">Sezione Link Utili</h3>
          <ul class="it-footer-small-prints-list list-inline mb-0 d-flex flex-column flex-md-row">
            <li class="list-inline-item"><a href="https://www.arpa.piemonte.it/privacy" target="_blank" title="Privacy-Cookies">Privacy policy</a></li>
            <li class="list-inline-item"><a href="https://www.arpa.piemonte.it/credits-1" target="_blank" title="Crediti">Credits</a></li>
            <li class="list-inline-item"><a href="https://www.arpa.piemonte.it/note-legali" target="_blank" title="Note Legali">Note legali</a></li>
          </ul>
        </div>
      </div>
    </footer>
</template>