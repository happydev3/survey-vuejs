<template>
  <div class="container">
    <div class="row m-3">
      <div class="col">
        <h1>Informazioni sul calcolatore dell'impronta di CO<sub>2</sub></h1>
        <hr/>
        <p>
          Multi-lingual (English / French / Italian) CO<sub>2</sub> Footprint calculator.
        </p>
        <p>
          Implementation based on [surveyjs.io](https://surveyjs.io/).
        </p>
        <div class="alert alert-danger"><b>ATTENZIONE</b> Lavori in corso !</div>
      </div>
    </div>
  </div>
</template>
